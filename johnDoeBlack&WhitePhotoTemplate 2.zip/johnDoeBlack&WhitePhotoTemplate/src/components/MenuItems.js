import React from 'react';

function MenuItems(props) {
    
  // Create a constant to loop through the items
  // The items JSON object is provided by Menu.js and passed in as a props
  const menuItemList = props.items.map((item) =>
    <div key={item.id}>
   
      <ul>{item.title}</ul>
      <p class="w3-text-grey">{item.content}</p>
      <p class="w3-container w3-padding-64 w3-light-grey w3-center w3-large"></p>
    </div>
  );
   
  // Create a basic structure with one element to load the items into
  return (
      <div className={"header"}>      
        {menuItemList}
      </div>
  );
}

export default MenuItems;
