import React from 'react';

import tableSetting from './tablesetting.jpg';
import sailboat from './sailboat.jpg';
import underwater from './underwater.jpg';
import rocks from './rocks.jpg';
import p6 from './p6.jpg';
import chef from './chef.jpg';
import bandmember from './bandmember.jpg';

import nature from './nature.jpg';
import ocean from './ocean.jpg';
import mist from './mist.jpg';
import mountainskies from './mountainskies.jpg';
import paris from './paris.jpg';
import falls2 from './falls2.jpg';
import wedding from './wedding.jpg';


import MenuItems from './MenuItems';

function Menu() {
  return (
    <div className="w3-content" style={{maxWidth: '1500px'}}>
        <header className="w3-panel w3-center w3-opacity" style={{padding: '128px 16px'}}>
        <h1 className="w3-xlarge">PHOTOGRAPHER</h1>
        <h1>John Doe</h1>
        <div className="w3-padding-32">
          <div className="w3-bar w3-border">
            <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button">Home</a>
            <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button w3-light-grey">Portfolio</a>
            <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button">Contact</a>
            <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button w3-hide-small">Weddings</a>
          </div>
        </div>
      </header>

      <div className="w3-row-padding w3-grayscale" style={{marginBottom: '128px'}}>
            <div className="w3-half">
          <img src={wedding} className="tableSetting" alt="Menu" style={{width:'100%'}} />
          <img src={underwater} className="sailboat" alt="gallary" style={{width:'100%'}} />
          <img src={sailboat} className="underwater" alt="gallary" style={{width:'100%'}} />
          <img src={rocks} className="rocks" alt="gallary" style={{width:'100%'}} />
          <img src={p6} className="p6" alt="gallary" style={{width:'100%'}} />
          <img src={chef} className="chef" alt="gallary" style={{width:'100%'}} />
          <img src={bandmember} className="bandmember" alt="gallary" style={{width:'100%'}} />
        </div>

        <div className="w3-half">
          <img src={nature} className="tableSetting" alt="gallary" style={{marginbottom:128}} />
          <img src={ocean} className="sailboat" alt="gallary" style={{width:'100%'}} />
          <img src={mist} className="underwater" alt="gallary" style={{width:'100%'}} />
          <img src={mountainskies} className="rocks" alt="gallary" style={{width:'100%'}} />
          <img src={paris} className="p6" alt="gallary" style={{width:'100%'}} />
          <img src={falls2} className="chef" alt="gallary" style={{width:'100%'}} />
          <img src={tableSetting} className="bandmember" alt="gallary" style={{width:'100%'}} />
        </div>
        </div>
    </div>

  );
}

// Create a JSON object storing all menu items
const items = [
  {id:1,title:'Home',},
  {id:2,title:'Portfolio'},
  {id:3,title:'Weddings'},
  {id:4,title:'Contact'},

];

export default Menu;




// var NewComponent = React.createClass({
//   render: function() {
//     return (
//       <div>
        
//         {/* !PAGE CONTENT! */}
//         <div className="w3-content" style={{maxWidth: '1500px'}}>
//           {/* Header */}
//           <header className="w3-panel w3-center w3-opacity" style={{padding: '128px 16px'}}>
//             <h1 className="w3-xlarge">PHOTOGRAPHER</h1>
//             <h1>John Doe</h1>
//             <div className="w3-padding-32">
//               <div className="w3-bar w3-border">
//                 <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button">Home</a>
//                 <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button w3-light-grey">Portfolio</a>
//                 <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button">Contact</a>
//                 <a href="https://www.w3schools.com/w3css/tryw3css_templates_photo2.htm#" className="w3-bar-item w3-button w3-hide-small">Weddings</a>
//               </div>
//             </div>
//           </header>
//           {/* Photo Grid */}
//           <div className="w3-row-padding w3-grayscale" style={{marginBottom: '128px'}}>
//             <div className="w3-half">
//               <img src="./W3.CSS Template_files/wedding.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/rocks.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/falls2.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/paris.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/nature.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/mist.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/paris.jpg" style={{width: '100%'}} />
//             </div>
//             <div className="w3-half">
//               <img src="./W3.CSS Template_files/underwater.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/ocean.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/wedding.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/mountainskies.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/rocks.jpg" style={{width: '100%'}} />
//               <img src="./W3.CSS Template_files/underwater.jpg" style={{width: '100%'}} />
//             </div>
//           </div>
//           {/* End Page Content */}
//         </div>
//         {/* Footer */}
//         <footer className="w3-container w3-padding-64 w3-light-grey w3-center w3-large"> 
//           <i className="fa fa-facebook-official w3-hover-opacity" />
//           <i className="fa fa-instagram w3-hover-opacity" />
//           <i className="fa fa-snapchat w3-hover-opacity" />
//           <i className="fa fa-pinterest-p w3-hover-opacity" />
//           <i className="fa fa-twitter w3-hover-opacity" />
//           <i className="fa fa-linkedin w3-hover-opacity" />
//           <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank" className="w3-hover-text-green">w3.css</a></p>
//         </footer>
//       </div>
//     );
//   }
// });