import React from 'react';

import facebook from './facebook.png';
import snapchat from './snapchat.png';
import pinterest from './pinterest.png';
import linkedin from './linkedin.png';
import twitter from './twitter.png';
import instagram from './instagram.png';


function Footer() {
  return ( 
       <footer className="footerContainer"> 
          <img src={facebook} className="facebook" alt="footer" style={{marginbottom:128}} />
          <img src={snapchat} className="snapchat" alt="footer" style={{width: 24}} />
          <img src={pinterest} className="pinterest" alt="footer" style={{width: 24}} />
          <img src={linkedin} className="linkedin" alt="footer" style={{width: 24}} />
          <img src={twitter} className="twitter" alt="footer" style={{width: 24}} />
          <img src={instagram} className="instagram" alt="footer" style={{width: 24}} />
          <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" target="_blank" className="w3-hover-text-green">w3.css</a></p>
        </footer>
  );
}
 
export default Footer;