import React from 'react';

// Import a component in the components folder
import Menu from './Menu';

function Content() {
  return (
      <div className="w3-content" style={{maxWidth:'1100px'}}>
      
        <hr />
        <Menu></Menu>
        <hr />
        
      </div>
  );
}

export default Content;
